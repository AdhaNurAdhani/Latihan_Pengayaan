<?php

define('baseurl','http://localhost/Latihan_pengayaan/public');